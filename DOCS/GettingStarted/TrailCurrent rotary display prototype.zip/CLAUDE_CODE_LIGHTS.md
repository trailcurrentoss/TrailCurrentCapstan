# Claude Code prompt: Lights focus carousel (EEZ Studio 0.29, LVGL 9)

Paste everything below the line into Claude Code.

---

The Lights screen you built is a scrollable list, which is wrong. Rebuild it in **EEZ Studio 0.29** (LVGL project, LVGL 9.x) as the **focus carousel** from `design/Rotary Dial.dc.html`. The screen shows **one light at a time, full-screen**. Turning the ring changes which light is shown, and pressing the ring toggles it. There is **no `lv_list`, no scrolling, no rows, and no multiple items on screen at once**. The content of a fixed set of widgets is swapped in place.

## 0. Before you start
1. Open the prototype in a browser and open **Lights**. If the side panel shows a Lights variant switcher, choose **Focus** (not Grid). Screenshot these states in both light and dark themes: a light that is on (Kitchen), a light that is off (Living), and a scene (Evening). These are the acceptance reference.
2. In the HTML, the screen is the `<sc-if value="{{ isLightsA }}">` block. Its logic is in `renderVals()`, under `// lights` (`lDots`, `lCur`, `lArc`), plus `rotate()` case `'lights'` and `press()` case `'lights'`.
3. Check that the project is LVGL 9.x and 480×480.

## 1. What the screen looks like
It is a round face with no header and no cards.
- A **thin 270° ring** sits near the edge (the same geometry as Air Quality and Energy, but 10px thick). The gap is at the bottom. When the selected light is **on**, the whole ring is filled green. When it is off, or a scene is selected, only the grey track shows. The ring is a state indicator, not a gauge.
- A **row of position dots** runs along the top of the ring, one per item and centered at 12 o'clock. The selected item's dot is larger and green; the others are small and grey. This row tells the user they are in a carousel.
- A **centered stack**:
  1. A **150px circle** holding a 72px bulb icon. When the light is on it has a pale green fill, a green border, and a soft green glow. When it is off it has a card-white fill, a grey border, a grey outline bulb, and no glow.
  2. The **name** (`Kitchen`), 32px medium weight.
  3. The **state** (`On` / `Off`, or `Scene · press to apply`), 20px, secondary color.

## 2. Items and behavior
The carousel has 9 items: 6 lights, then 3 scenes.
- Lights: `Kitchen`, `Living`, `Bedroom`, `Bath`, `Porch`, `Awning`. Build the list from the model at runtime; don't hard-code it.
- Scenes: `Evening` (icon `partly-sunny`) turns on Kitchen, Living, and Awning. `Night` (icon `moon`) turns on Bedroom and Bath. `All Off` (icon `power`) turns everything off. Applying a scene turns off every light that isn't in it.
- **Rotate**: move one item per detent, and **wrap** at both ends (`(i + d + n) % n`).
- **Press** on a light: toggle it on/off. There is no brightness. **Press** on a scene: apply it. The screen stays on the scene item, and the user can rotate back to see the lights that changed.
- **Tap on the circle**: toggle or apply, the same as press, so the screen works with touch alone. The prototype's circle tap only resets the idle timer; this is an intentional addition.
- **Long press**: go back to the menu, the same as on other screens.
- Keep the selected index in the model so reopening Lights returns to the last item.

### Encoder wiring (important)
Do not put 9 objects in the group. Put **one** object, the circle `lt_bulb`, in this screen's `lv_group_t`, and call `lv_group_set_editing(group, true)` so that rotation arrives as `LV_EVENT_KEY` with `LV_KEY_RIGHT`/`LV_KEY_LEFT` on `lt_bulb`. Handle those keys by changing the index. Handle `LV_EVENT_CLICKED` (ring press, or touch tap) by toggling. Turn editing mode back off when the screen unloads, so other screens still navigate normally.

## 3. Geometry (px, 480×480 screen, origin top-left, center 240,240)
Angles use LVGL's convention (0° = 3 o'clock, increasing clockwise), which matches the prototype's SVG math.

**Ring (`lt_arc`, `lv_arc`)**
- The centerline radius is 214 and the stroke is 10, so the object is **438×438** (2 × (214 + 5)), centered.
- `rotation = 135`, `bg_start_angle = 0`, `bg_end_angle = 270`, `range 0..1`. The value is 1 when the selected light is on and 0 otherwise. At 0, set the INDICATOR `arc_opa = 0`, because a zero-length rounded arc still draws a dot.
- MAIN: `arc_width 10`, `arc_rounded 1`, color = track. INDICATOR: `arc_width 10`, `arc_rounded 1`, color `#52A441`.
- KNOB: fully transparent, `pad_all 0`. Clear the `CLICKABLE` flag and keep the arc out of the group.

**Position dots (`lt_dots`)**
- Create N small `lv_obj`s at runtime in a hand-written hook, not in generated code. They are round (`radius LV_RADIUS_CIRCLE`), with `border_width 0` and `pad_all 0`.
- Dot *i* of N sits on radius **222**, at angle `270 + (i − (N−1)/2) × 7` degrees. The center is `x = 240 + 222·cos(a)`, `y = 240 + 222·sin(a)`. Place each dot with `lv_obj_set_pos(dot, x − size/2, y − size/2)`.
- Inactive dots are **10×10**, colored with the track color. The active dot is **14×14**, colored primary (`#52A441` light, `#7BC96A` dark).
- The dots overlap the inner edge of the ring slightly. As in the prototype, create them **before** `lt_arc` so the ring draws over their inner edge.
- Reference centers for N = 9 (rounded): (136,44) (160,33) (186,25) (213,20) (240,18) (267,20) (294,25) (320,33) (344,44).

**Center stack (`lt_stack`)**
- A content-sized `lv_obj`, centered, flex column, all place values CENTER, **row gap 10**.
- `lt_bulb`: 150×150, `radius LV_RADIUS_CIRCLE`, `border_width 2`. Put a centered icon label (`lt_icon`) inside it.
- `lt_name`: add **margin-top 6**. If the margin doesn't take effect, add 6 to the gap above this label only.
- `lt_state` has no extra spacing.

## 4. Typography and icons
Use the Roboto family. Create each font in EEZ **Fonts** at 4 bpp, and reuse existing fonts if the names match:
- `ui_font_med_32`: Roboto-Medium 32, Basic Latin. Used by `lt_name`.
- `ui_font_reg_20`: Roboto-Regular 20, Basic Latin plus `·` (U+00B7). Used by `lt_state`.
- `ui_icons_72`: the Ionicons glyphs **bulb**, **bulb-outline**, **partly-sunny**, **moon**, and **power** only, at 72px. Convert the Ionicons SVGs to a TTF (with IcoMoon or fantasticon), then add that TTF in EEZ with only those codepoints. Record the codepoint map in `docs/icons.md`, and put the icon strings in `ui_icons.h` as UTF-8 `#define`s.
  - An alternative if the font route is blocked: 72×72 **A8** images in EEZ **Images**, recolored at runtime with `image_recolor` + `image_recolor_opa 255`. Use the font if possible, because it recolors through `text_color` like everything else.

Text colors: name = text-primary. State = text-secondary.

## 5. Colors and states
All values come from `design/colors_and_type.css`.

| Token | Light (default) | Dark |
| --- | --- | --- |
| Screen bg | `#f5f5f5` | `#000000` |
| Card bg (off circle) | `#ffffff` | `#1a1a1a` |
| Track / off border / inactive dot | `#dddddd` | `#333333` |
| Primary (on icon, active dot) | `#52A441` | `#7BC96A` |
| Primary container (on circle fill) | `#DCEDD9` | `#3D7B31` |
| Text primary | `#1a1a1a` | `#ffffff` |
| Text secondary (state line, scene icon) | `#4a4a4a` | `#aaaaaa` |
| Text muted (off icon) | `#888888` | `#666666` |

The ring indicator and the on-circle border use `#52A441` in both themes.

**On** (light selected and on): use `LV_STATE_CHECKED` on `lt_bulb`.
- bg = primary container, `border_color #52A441`
- **Glow**: `shadow_width 40`, `shadow_spread 0`, `shadow_ofs 0,0`, `shadow_color #52A441`, `shadow_opa 128` (50%)
- icon `bulb` in primary. `lt_arc` value 1, indicator visible. State text `On`.

**Off**: `lt_bulb` default state.
- bg = card, border = track color, `shadow_opa 0`
- icon `bulb-outline` in text-muted. `lt_arc` indicator hidden. State text `Off`.

**Scene selected**: `lt_bulb` default state.
- Same circle as Off, but the icon is the scene's icon in text-secondary. Arc hidden. State text `Scene · press to apply`.

Use style states (CHECKED vs default) for the circle so the theme swap and the transition happen automatically. Add an `lv_style_transition_dsc_t` on `lt_bulb` for `bg_color`, `border_color`, `shadow_opa`, and `shadow_width`, at **200 ms** with `lv_anim_path_ease_in_out`. The system's transition is `0.2s ease`. There is no bounce, slide, or scale.

**Changing items does not animate position.** On rotate, update the name, state, icon, circle state, arc, and active dot directly. The circle's style transition is the only motion.

Performance: a 40px shadow on a 150px circle is expensive in LVGL. Check that it doesn't hurt ring responsiveness on the target hardware (goal: no dropped detents, ≥30 fps). If it does, first try `shadow_width 30`, then a static A8 glow image placed behind the circle. Record what you chose.

## 6. Strip the LVGL defaults
- `lt_stack`: `bg_opa 0`, `border_width 0`, `pad_all 0`, `radius 0`, not scrollable, scrollbar off.
- `lt_bulb`: clear `SCROLLABLE` and `SCROLL_ON_FOCUS`. Remove the default theme's focus outline: set `outline_width 0` for `LV_STATE_FOCUSED` and `LV_STATE_FOCUS_KEY`, because the default theme draws a blue/green ring around focused objects. Remove the default pressed darkening (`bg_color` filter). The circle has `pad_all 0`, and the icon is centered with `LV_ALIGN_CENTER`.
- Screen: `pad_all 0`, not scrollable.
- Never use `lv_list`, `lv_roller`, `lv_tabview`, or a scrolling container on this screen.

## 7. Data and code layout
- Model (`src/model/lights.c`): `light_t { char name[16]; bool on; }` array, a `scene_t` array, a `lights_sel` index, and `lights_toggle(i)` / `lights_apply_scene(k)`. These publish MQTT commands and update the state optimistically. The UI only reads the model.
- Screen logic (`src/ui_logic/lights_carousel.c`): `lights_carousel_post_create()` builds the dots and sets up the group and event handlers. `lights_carousel_refresh()` applies the model to the widgets. Call refresh from an observer (an `lv_subject_t`, or EEZ native-variable change detection) whenever the model changes, including changes from MQTT while the screen is visible.
- EEZ variables, if you are binding in the designer: `lights_sel_name` (string), `lights_sel_state` (string), `lights_sel_on` (bool, drives the CHECKED state and the arc), `lights_sel_icon` (string). Keep the generated code in `src/ui/` untouched.
- Missing data (MQTT not yet received): the state shows `--`, the circle uses the Off styling, and press does nothing.

## 8. Acceptance
In the simulator at 480×480, capture Kitchen on, Living off, the Evening scene, and wrap-around from Awning to Evening to All Off to Kitchen, in both themes. Put the captures next to the prototype screenshots and check that:
- only one item is ever on screen, and there is no scrollbar or list styling
- the dot row sits along the top of the ring, and the active dot moves one step per detent and wraps
- the ring is completely filled green when the item is on and shows only the grey track otherwise
- the on-circle has the pale green fill, green border, and visible soft glow, and fades to the off look over about 200 ms
- there is no default focus outline on the circle
- ring press and circle tap both toggle, and long press goes back
- the theme toggle recolors everything, including the dots

Commit the captures to `docs/screens/lights/`, and list any deviations with reasons.
