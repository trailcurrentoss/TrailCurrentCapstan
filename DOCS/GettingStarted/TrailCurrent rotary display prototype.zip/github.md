repo: trailcurrentoss/Utilities-LogoFreeCADPlugin
branch: main
path: resources/icons

## Last sync
date: 2026-09-28T20:27:46Z

### Updated in this project
- TrailCurrent logo (TrailCurrentLogo.svg) used on the TrailCurrent clock face

## Screen map
| Screen | Repo files |
| --- | --- |
| Idle clock, TrailCurrent face | resources/icons/TrailCurrentLogo.svg |
